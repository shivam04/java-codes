﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CalculatorCommonLib
{
    public class Consts
    {
        public const int MethodCallCount = 1000000;
    }
}
