﻿namespace ClientApp
{
    class Program
    {
        static void Main()
        {
            DuplexClientCustomProtocolSynchronized.Run();
        }
    }
}
