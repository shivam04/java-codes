﻿namespace ServerApp
{
    public class Program
    {
        static void Main()
        {
            DuplexServerCustomProtocol.Run();
        }
    }
}
